/**
 * # GCP Cloud Storage Bucket Module
 *
 * This module creates a Google Cloud Storage bucket with enterprise-grade features including:
 * - Security controls (encryption, access prevention, IAM, VPC-SC)
 * - Data protection (versioning, retention, lifecycle)
 * - Performance optimization (replication, hierarchical namespace)
 * - Operational features (logging, monitoring, labels)
 */

locals {
  # Validate bucket name against GCP naming conventions
  bucket_name_regex = "^[a-z0-9][-_.a-z0-9]*[a-z0-9]$"
  is_valid_name     = can(regex(local.bucket_name_regex, var.bucket_name))

  # Construct the full bucket name with prefix if provided
  bucket_name = var.bucket_prefix != null ? "${var.bucket_prefix}-${var.bucket_name}" : var.bucket_name

  # Default labels merged with user-provided labels
  default_labels = {
    managed_by = "terraform"
    module     = "gcs-bucket"
  }
  labels = merge(local.default_labels, var.labels)

  # Validate CMEK key format if provided
  is_valid_kms_key = var.encryption_key == null ? true : can(regex("^projects/[^/]+/locations/[^/]+/keyRings/[^/]+/cryptoKeys/[^/]+$", var.encryption_key))

  # Validate lifecycle rule conflicts
  has_versioning_enabled = var.versioning_enabled
  has_retention_policy   = var.retention_policy != null

  # Validate IAM roles format
  iam_roles = { for member, roles in var.iam_members : member => roles if can(tolist(roles)) }
  
  # Determine if we need to create a regional replication job
  create_regional_replication = var.regional_replication_config != null
  
  # Determine if we need to create a turbo replication job
  create_turbo_replication = var.turbo_replication_config != null
  
  # Resource naming with gcs_ prefix
  resource_prefix = "gcs_"
}

# Validation checks
resource "null_resource" "gcs_validations" {
  lifecycle {
    precondition {
      condition     = local.is_valid_name
      error_message = "Bucket name must follow GCP naming conventions: ${local.bucket_name_regex}"
    }

    precondition {
      condition     = local.is_valid_kms_key
      error_message = "Invalid KMS key format. Must be: projects/[PROJECT]/locations/[LOCATION]/keyRings/[KEYRING]/cryptoKeys/[KEY]"
    }

    precondition {
      condition     = !(local.has_retention_policy && !local.has_versioning_enabled)
      error_message = "Retention policy requires versioning to be enabled"
    }
    
    precondition {
      condition     = !(var.turbo_replication_config != null && var.replication_config != null)
      error_message = "Cannot configure both standard replication and turbo replication simultaneously"
    }
    
    precondition {
      condition     = !(var.regional_replication_config != null && var.replication_config != null)
      error_message = "Cannot configure both cross-region and regional replication simultaneously"
    }
    
    precondition {
      condition     = !(var.regional_replication_config != null && var.turbo_replication_config != null)
      error_message = "Cannot configure both regional and turbo replication simultaneously"
    }
  }
}

# Main GCS bucket resource
resource "google_storage_bucket" "gcs_bucket" {
  name                        = local.bucket_name
  location                    = var.location
  project                     = var.project_id
  storage_class               = var.storage_class
  uniform_bucket_level_access = var.uniform_bucket_level_access
  labels                      = local.labels
  force_destroy               = var.force_destroy
  public_access_prevention    = var.public_access_prevention ? "enforced" : "inherited"
  requester_pays              = var.requester_pays

  # Versioning configuration
  dynamic "versioning" {
    for_each = var.versioning_enabled ? [1] : []
    content {
      enabled = true
    }
  }

  # Encryption configuration
  dynamic "encryption" {
    for_each = var.encryption_key != null ? [1] : []
    content {
      default_kms_key_name = var.encryption_key
    }
  }

  # Website configuration
  dynamic "website" {
    for_each = var.website != null ? [var.website] : []
    content {
      main_page_suffix = website.value.main_page_suffix
      not_found_page   = website.value.not_found_page
    }
  }

  # CORS configuration
  dynamic "cors" {
    for_each = var.cors_rules != null ? var.cors_rules : []
    content {
      origin          = cors.value.origin
      method          = cors.value.method
      response_header = cors.value.response_header
      max_age_seconds = cors.value.max_age_seconds
    }
  }

  # Lifecycle rules
  dynamic "lifecycle_rule" {
    for_each = var.lifecycle_rules != null ? var.lifecycle_rules : []
    content {
      action {
        type          = lifecycle_rule.value.action.type
        storage_class = lookup(lifecycle_rule.value.action, "storage_class", null)
      }
      condition {
        age                        = lookup(lifecycle_rule.value.condition, "age", null)
        created_before             = lookup(lifecycle_rule.value.condition, "created_before", null)
        with_state                 = lookup(lifecycle_rule.value.condition, "with_state", null)
        matches_storage_class      = lookup(lifecycle_rule.value.condition, "matches_storage_class", null)
        num_newer_versions         = lookup(lifecycle_rule.value.condition, "num_newer_versions", null)
        days_since_noncurrent_time = lookup(lifecycle_rule.value.condition, "days_since_noncurrent_time", null)
        custom_time_before         = lookup(lifecycle_rule.value.condition, "custom_time_before", null)
      }
    }
  }

  # Retention policy
  dynamic "retention_policy" {
    for_each = var.retention_policy != null ? [var.retention_policy] : []
    content {
      retention_period = retention_policy.value.retention_period
      is_locked        = lookup(retention_policy.value, "is_locked", false)
    }
  }

  # Logging configuration
  dynamic "logging" {
    for_each = var.logging_config != null ? [var.logging_config] : []
    content {
      log_bucket        = logging.value.log_bucket
      log_object_prefix = lookup(logging.value, "log_object_prefix", null)
    }
  }

  # Autoclass configuration
  dynamic "autoclass" {
    for_each = var.autoclass_enabled ? [1] : []
    content {
      enabled                      = true
      terminal_storage_class       = var.autoclass_terminal_storage_class
      terminal_storage_class_days  = var.autoclass_terminal_storage_class_days
    }
  }

  # Custom placement configuration
  dynamic "custom_placement_config" {
    for_each = var.custom_placement_config != null ? [var.custom_placement_config] : []
    content {
      data_locations = custom_placement_config.value.data_locations
    }
  }

  # Hierarchical namespace
  dynamic "hierarchical_namespace" {
    for_each = var.hierarchical_namespace_enabled ? [1] : []
    content {
      enabled = true
    }
  }

  # Soft delete policy
  dynamic "soft_delete_policy" {
    for_each = var.soft_delete_policy_retention_duration_days != null ? [1] : []
    content {
      retention_duration_seconds = var.soft_delete_policy_retention_duration_days * 86400
    }
  }

  # Depends on validation
  depends_on = [null_resource.gcs_validations]
}

# IAM policy bindings for the bucket
resource "google_storage_bucket_iam_member" "gcs_bucket_iam_members" {
  for_each = { for entry in flatten([
    for member, roles in local.iam_roles : [
      for role in roles : {
        member = member
        role   = role
      }
    ]
  ]) : "${entry.member}-${entry.role}" => entry }

  bucket = google_storage_bucket.gcs_bucket.name
  role   = each.value.role
  member = each.value.member

  dynamic "condition" {
    for_each = var.iam_conditions != null ? lookup(var.iam_conditions, each.value.member, null) != null ? [lookup(var.iam_conditions, each.value.member)] : [] : []
    content {
      title       = condition.value.title
      description = lookup(condition.value, "description", null)
      expression  = condition.value.expression
    }
  }
}

# Notification configuration
resource "google_storage_notification" "gcs_notification" {
  count          = var.notification_config != null ? 1 : 0
  bucket         = google_storage_bucket.gcs_bucket.name
  payload_format = var.notification_config.payload_format
  topic          = var.notification_config.topic
  event_types    = lookup(var.notification_config, "event_types", null)
  custom_attributes = lookup(var.notification_config, "custom_attributes", null)
  depends_on     = [google_storage_bucket.gcs_bucket]
}

# Cross-region replication configuration using Storage Transfer Service
resource "google_storage_transfer_job" "gcs_replication_job" {
  count       = var.replication_config != null ? 1 : 0
  description = "Cross-region replication job for bucket ${google_storage_bucket.gcs_bucket.name}"
  project     = var.project_id

  transfer_spec {
    gcs_data_source {
      bucket_name = google_storage_bucket.gcs_bucket.name
    }
    gcs_data_sink {
      bucket_name = var.replication_config.destination_bucket
    }
    transfer_options {
      delete_objects_from_source_after_transfer = false
      overwrite_objects_already_existing_in_sink = var.replication_config.overwrite_destination
    }
  }

  schedule {
    schedule_start_date {
      year  = var.replication_config.schedule.year
      month = var.replication_config.schedule.month
      day   = var.replication_config.schedule.day
    }
    start_time_of_day {
      hours   = lookup(var.replication_config.schedule, "hours", 0)
      minutes = lookup(var.replication_config.schedule, "minutes", 0)
      seconds = lookup(var.replication_config.schedule, "seconds", 0)
      nanos   = lookup(var.replication_config.schedule, "nanos", 0)
    }
    repeat_interval = var.replication_config.repeat_interval
  }

  depends_on = [google_storage_bucket.gcs_bucket]
}

# Regional replication configuration
resource "google_storage_transfer_job" "gcs_regional_replication_job" {
  count       = local.create_regional_replication ? 1 : 0
  description = "Regional replication job for bucket ${google_storage_bucket.gcs_bucket.name}"
  project     = var.project_id

  transfer_spec {
    gcs_data_source {
      bucket_name = google_storage_bucket.gcs_bucket.name
    }
    gcs_data_sink {
      bucket_name = var.regional_replication_config.destination_bucket
    }
    object_conditions {
      min_time_elapsed_since_last_modification = var.regional_replication_config.min_time_elapsed_seconds
      include_prefixes = lookup(var.regional_replication_config, "include_prefixes", null)
      exclude_prefixes = lookup(var.regional_replication_config, "exclude_prefixes", null)
    }
    transfer_options {
      delete_objects_from_source_after_transfer = false
      overwrite_objects_already_existing_in_sink = var.regional_replication_config.overwrite_destination
    }
  }

  schedule {
    schedule_start_date {
      year  = var.regional_replication_config.schedule.year
      month = var.regional_replication_config.schedule.month
      day   = var.regional_replication_config.schedule.day
    }
    start_time_of_day {
      hours   = lookup(var.regional_replication_config.schedule, "hours", 0)
      minutes = lookup(var.regional_replication_config.schedule, "minutes", 0)
      seconds = lookup(var.regional_replication_config.schedule, "seconds", 0)
    }
    repeat_interval = var.regional_replication_config.repeat_interval
  }

  depends_on = [google_storage_bucket.gcs_bucket]
}

# Turbo Replication configuration
resource "google_storage_bucket_object" "gcs_turbo_replication_trigger" {
  count   = local.create_turbo_replication ? 1 : 0
  name    = ".turbo_replication_trigger"
  content = "This file triggers the Cloud Function for turbo replication"
  bucket  = google_storage_bucket.gcs_bucket.name
}

resource "google_storage_bucket" "gcs_turbo_replication_destination" {
  count                       = local.create_turbo_replication && var.turbo_replication_config.create_destination_bucket ? 1 : 0
  name                        = var.turbo_replication_config.destination_bucket
  location                    = var.turbo_replication_config.destination_location
  project                     = var.project_id
  storage_class               = lookup(var.turbo_replication_config, "destination_storage_class", "STANDARD")
  uniform_bucket_level_access = true
  labels                      = merge(local.labels, { "replication_type" = "turbo_destination" })
}

resource "google_pubsub_topic" "gcs_turbo_replication_topic" {
  count   = local.create_turbo_replication ? 1 : 0
  name    = "${local.resource_prefix}turbo_replication_topic_${google_storage_bucket.gcs_bucket.name}"
  project = var.project_id
}

resource "google_storage_notification" "gcs_turbo_replication_notification" {
  count          = local.create_turbo_replication ? 1 : 0
  bucket         = google_storage_bucket.gcs_bucket.name
  payload_format = "JSON_API_V1"
  topic          = google_pubsub_topic.gcs_turbo_replication_topic[0].id
  event_types    = ["OBJECT_FINALIZE", "OBJECT_METADATA_UPDATE"]
  
  depends_on = [
    google_storage_bucket.gcs_bucket,
    google_pubsub_topic.gcs_turbo_replication_topic
  ]
}

resource "google_service_account" "gcs_turbo_replication_service_account" {
  count        = local.create_turbo_replication ? 1 : 0
  account_id   = "${local.resource_prefix}turbo_repl_sa_${substr(google_storage_bucket.gcs_bucket.name, 0, 8)}"
  display_name = "Turbo Replication Service Account for ${google_storage_bucket.gcs_bucket.name}"
  project      = var.project_id
}

resource "google_storage_bucket_iam_member" "gcs_turbo_replication_source_reader" {
  count  = local.create_turbo_replication ? 1 : 0
  bucket = google_storage_bucket.gcs_bucket.name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.gcs_turbo_replication_service_account[0].email}"
}

resource "google_storage_bucket_iam_member" "gcs_turbo_replication_destination_writer" {
  count  = local.create_turbo_replication ? 1 : 0
  bucket = var.turbo_replication_config.create_destination_bucket ? google_storage_bucket.gcs_turbo_replication_destination[0].name : var.turbo_replication_config.destination_bucket
  role   = "roles/storage.objectCreator"
  member = "serviceAccount:${google_service_account.gcs_turbo_replication_service_account[0].email}"
}

resource "google_pubsub_topic_iam_member" "gcs_turbo_replication_topic_subscriber" {
  count   = local.create_turbo_replication ? 1 : 0
  topic   = google_pubsub_topic.gcs_turbo_replication_topic[0].name
  role    = "roles/pubsub.subscriber"
  member  = "serviceAccount:${google_service_account.gcs_turbo_replication_service_account[0].email}"
  project = var.project_id
}

resource "google_cloudfunctions_function" "gcs_turbo_replication_function" {
  count       = local.create_turbo_replication ? 1 : 0
  name        = "${local.resource_prefix}turbo_replication_${substr(google_storage_bucket.gcs_bucket.name, 0, 10)}"
  description = "Function for turbo replication from ${google_storage_bucket.gcs_bucket.name} to ${var.turbo_replication_config.destination_bucket}"
  runtime     = "python39"
  project     = var.project_id
  region      = var.turbo_replication_config.function_region
  
  available_memory_mb   = lookup(var.turbo_replication_config, "function_memory_mb", 256)
  source_archive_bucket = var.turbo_replication_config.function_source_bucket
  source_archive_object = var.turbo_replication_config.function_source_object
  
  event_trigger {
    event_type = "google.pubsub.topic.publish"
    resource   = google_pubsub_topic.gcs_turbo_replication_topic[0].name
  }
  
  environment_variables = {
    SOURCE_BUCKET      = google_storage_bucket.gcs_bucket.name
    DESTINATION_BUCKET = var.turbo_replication_config.create_destination_bucket ? google_storage_bucket.gcs_turbo_replication_destination[0].name : var.turbo_replication_config.destination_bucket
    INCLUDE_PATTERNS   = jsonencode(lookup(var.turbo_replication_config, "include_patterns", []))
    EXCLUDE_PATTERNS   = jsonencode(lookup(var.turbo_replication_config, "exclude_patterns", []))
  }
  
  service_account_email = google_service_account.gcs_turbo_replication_service_account[0].email
  
  depends_on = [
    google_storage_bucket.gcs_bucket,
    google_pubsub_topic.gcs_turbo_replication_topic,
    google_service_account.gcs_turbo_replication_service_account
  ]
}

# VPC Service Controls integration
resource "google_access_context_manager_service_perimeter" "gcs_vpc_sc_perimeter" {
  count          = var.vpc_sc_config != null ? 1 : 0
  name           = "accessPolicies/${var.vpc_sc_config.access_policy}/servicePerimeters/${local.resource_prefix}perimeter_${google_storage_bucket.gcs_bucket.name}"
  title          = "${local.resource_prefix}perimeter_${google_storage_bucket.gcs_bucket.name}"
  perimeter_type = "PERIMETER_TYPE_REGULAR"
  parent         = "accessPolicies/${var.vpc_sc_config.access_policy}"
  
  status {
    resources = ["projects/${var.project_id}"]
    restricted_services = ["storage.googleapis.com"]
    
    vpc_accessible_services {
      enable_restriction = true
      allowed_services   = ["storage.googleapis.com"]
    }
    
    ingress_policies {
      ingress_from {
        sources {
          access_level = var.vpc_sc_config.access_level
        }
        identity_type = "ANY_IDENTITY"
      }
      ingress_to {
        resources = ["projects/${var.project_id}"]
        operations {
          service_name = "storage.googleapis.com"
          method_selectors {
            method = "*"
          }
        }
      }
    }
    
    egress_policies {
      egress_from {
        identities = var.vpc_sc_config.allowed_egress_identities
      }
      egress_to {
        resources = ["*"]
        operations {
          service_name = "storage.googleapis.com"
          method_selectors {
            method = "*"
          }
        }
      }
    }
  }
}

# Audit logging configuration
resource "google_project_iam_audit_config" "gcs_audit_logging" {
  count   = var.enable_audit_logging ? 1 : 0
  project = var.project_id
  service = "storage.googleapis.com"
  
  audit_log_config {
    log_type = "ADMIN_READ"
  }
  
  audit_log_config {
    log_type = "DATA_READ"
  }
  
  audit_log_config {
    log_type = "DATA_WRITE"
  }
}

# Cloud Monitoring alerting policy
resource "google_monitoring_alert_policy" "gcs_bucket_alert_policy" {
  count        = var.monitoring_alert_config != null ? 1 : 0
  display_name = "${local.resource_prefix}alert_policy_${google_storage_bucket.gcs_bucket.name}"
  project      = var.project_id
  combiner     = "OR"
  
  conditions {
    display_name = "High number of access denied errors"
    condition_threshold {
      filter          = "resource.type = \"gcs_bucket\" AND resource.labels.bucket_name = \"${google_storage_bucket.gcs_bucket.name}\" AND metric.type = \"storage.googleapis.com/api/request_count\" AND metric.labels.response_code = \"403\""
      duration        = var.monitoring_alert_config.duration
      comparison      = "COMPARISON_GT"
      threshold_value = var.monitoring_alert_config.access_denied_threshold
      
      aggregations {
        alignment_period   = var.monitoring_alert_config.alignment_period
        per_series_aligner = "ALIGN_RATE"
      }
      
      trigger {
        count = var.monitoring_alert_config.trigger_count
      }
    }
  }
  
  conditions {
    display_name = "Unusual access patterns"
    condition_threshold {
      filter          = "resource.type = \"gcs_bucket\" AND resource.labels.bucket_name = \"${google_storage_bucket.gcs_bucket.name}\" AND metric.type = \"storage.googleapis.com/api/request_count\""
      duration        = var.monitoring_alert_config.duration
      comparison      = "COMPARISON_GT"
      threshold_value = var.monitoring_alert_config.unusual_access_threshold
      
      aggregations {
        alignment_period   = var.monitoring_alert_config.alignment_period
        per_series_aligner = "ALIGN_RATE"
      }
      
      trigger {
        count = var.monitoring_alert_config.trigger_count
      }
    }
  }
  
  notification_channels = var.monitoring_alert_config.notification_channels
  
  documentation {
    content   = "Alert for unusual activity on bucket ${google_storage_bucket.gcs_bucket.name}"
    mime_type = "text/markdown"
  }
  
  depends_on = [google_storage_bucket.gcs_bucket]
}

# Hybrid cloud transfer configuration
resource "google_storage_transfer_job" "gcs_hybrid_transfer_job" {
  count       = var.hybrid_transfer_config != null ? 1 : 0
  description = "Hybrid transfer job for bucket ${google_storage_bucket.gcs_bucket.name}"
  project     = var.project_id
  
  transfer_spec {
    # Source configuration based on transfer type
    dynamic "aws_s3_data_source" {
      for_each = var.hybrid_transfer_config.transfer_type == "AWS_S3" ? [1] : []
      content {
        bucket_name = var.hybrid_transfer_config.source_aws_bucket
        aws_access_key {
          access_key_id     = var.hybrid_transfer_config.aws_access_key_id
          secret_access_key = var.hybrid_transfer_config.aws_secret_access_key
        }
      }
    }
    
    dynamic "http_data_source" {
      for_each = var.hybrid_transfer_config.transfer_type == "HTTP" ? [1] : []
      content {
        list_url = var.hybrid_transfer_config.http_list_url
      }
    }
    
    dynamic "posix_data_source" {
      for_each = var.hybrid_transfer_config.transfer_type == "POSIX" ? [1] : []
      content {
        root_directory = var.hybrid_transfer_config.posix_root_directory
      }
    }
    
    dynamic "azure_blob_storage_data_source" {
      for_each = var.hybrid_transfer_config.transfer_type == "AZURE_BLOB" ? [1] : []
      content {
        container = var.hybrid_transfer_config.azure_container
        storage_account = var.hybrid_transfer_config.azure_storage_account
        azure_credentials {
          sas_token = var.hybrid_transfer_config.azure_sas_token
        }
      }
    }
    
    # Destination is always the GCS bucket
    gcs_data_sink {
      bucket_name = google_storage_bucket.gcs_bucket.name
      path        = lookup(var.hybrid_transfer_config, "destination_path", "")
    }
    
    # Transfer options
    transfer_options {
      delete_objects_from_source_after_transfer = lookup(var.hybrid_transfer_config, "delete_from_source", false)
      overwrite_objects_already_existing_in_sink = lookup(var.hybrid_transfer_config, "overwrite_destination", true)
    }
    
    # Object conditions
    dynamic "object_conditions" {
      for_each = var.hybrid_transfer_config.object_conditions != null ? [var.hybrid_transfer_config.object_conditions] : []
      content {
        min_time_elapsed_since_last_modification = lookup(object_conditions.value, "min_time_elapsed_seconds", null)
        max_time_elapsed_since_last_modification = lookup(object_conditions.value, "max_time_elapsed_seconds", null)
        include_prefixes                         = lookup(object_conditions.value, "include_prefixes", null)
        exclude_prefixes                         = lookup(object_conditions.value, "exclude_prefixes", null)
      }
    }
  }
  
  # Schedule configuration
  schedule {
    schedule_start_date {
      year  = var.hybrid_transfer_config.schedule.year
      month = var.hybrid_transfer_config.schedule.month
      day   = var.hybrid_transfer_config.schedule.day
    }
    
    start_time_of_day {
      hours   = lookup(var.hybrid_transfer_config.schedule, "hours", 0)
      minutes = lookup(var.hybrid_transfer_config.schedule, "minutes", 0)
      seconds = lookup(var.hybrid_transfer_config.schedule, "seconds", 0)
      nanos   = lookup(var.hybrid_transfer_config.schedule, "nanos", 0)
    }
    
    repeat_interval = lookup(var.hybrid_transfer_config, "repeat_interval", "86400s")
  }
  
  depends_on = [google_storage_bucket.gcs_bucket]
}