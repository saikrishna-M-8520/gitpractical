package test

import (
    "context"
    "fmt"
    "strings"
    "testing"
    "time"

    "cloud.google.com/go/storage"
    "github.com/gruntwork-io/terratest/modules/gcp"
    "github.com/gruntwork-io/terratest/modules/random"
    "github.com/gruntwork-io/terratest/modules/terraform"
    "github.com/stretchr/testify/assert"
    "github.com/stretchr/testify/require"
    "google.golang.org/api/iterator"
    "google.golang.org/api/monitoring/v3"
    "google.golang.org/api/option"
    "google.golang.org/api/storagetransfer/v1"
)

func TestGCSBucketModule(t *testing.T) {
    t.Parallel()

    // Generate a random project name to prevent parallel test conflicts
    uniqueID := random.UniqueId()
    bucketPrefix := fmt.Sprintf("terratest-%s", uniqueID)

    // Get the Project ID to use
    projectID := gcp.GetGoogleProjectIDFromEnvVar(t)

    // Create a test service account for IAM testing
    serviceAcctID := fmt.Sprintf("terratest-sa-%s", uniqueID)
    serviceAcctEmail := gcp.CreateServiceAccountE(t, projectID, serviceAcctID, "Terratest Service Account")
    defer gcp.DeleteServiceAccountE(t, projectID, serviceAcctEmail)

    // Construct the terraform options with default retryable errors
    terraformOptions := &terraform.Options{
        // The path to where our Terraform code is located
        TerraformDir: "../test",

        // Variables to pass to our Terraform code using -var options
        Vars: map[string]interface{}{
            "project_id":           projectID,
            "region":               "us-central1",
            "test_bucket_prefix":   bucketPrefix,
            "test_service_account": serviceAcctEmail,
            // Enable specific tests based on environment capabilities
            "enable_vpc_sc_test":            false, // Requires VPC-SC setup
            "enable_replication_test":       true,
            "enable_turbo_replication_test": false, // Requires function source
            "enable_monitoring_test":        false, // Requires notification channels
            "enable_hybrid_transfer_test":   false, // Requires external sources
        },

        // Environment variables to set when running Terraform
        EnvVars: map[string]string{
            "GOOGLE_CLOUD_PROJECT": projectID,
        },
    }

    // At the end of the test, run `terraform destroy` to clean up any resources that were created
    defer terraform.Destroy(t, terraformOptions)

    // This will run `terraform init` and `terraform apply` and fail the test if there are any errors
    terraform.InitAndApply(t, terraformOptions)

    // Run `terraform output` to get the values of output variables
    basicBucketName := terraform.Output(t, terraformOptions, "basic_bucket_name")
    advancedBucketName := terraform.Output(t, terraformOptions, "advanced_bucket_name")

    // Verify that the buckets exist
    t.Run("BucketExists", func(t *testing.T) {
        assertBucketExists(t, projectID, basicBucketName)
        assertBucketExists(t, projectID, advancedBucketName)
    })

    // Test basic bucket properties
    t.Run("BasicBucketProperties", func(t *testing.T) {
        bucket := getBucket(t, projectID, basicBucketName)
        assert.Equal(t, "STANDARD", bucket.StorageClass)
        assert.Equal(t, "us-central1", bucket.Location)
        assert.True(t, bucket.VersioningEnabled)
        assert.True(t, bucket.UniformBucketLevelAccess)
    })

    // Test advanced bucket properties
    t.Run("AdvancedBucketProperties", func(t *testing.T) {
        bucket := getBucket(t, projectID, advancedBucketName)
        
        // Check storage class
        assert.Equal(t, "STANDARD", bucket.StorageClass)
        
        // Check versioning
        assert.True(t, bucket.VersioningEnabled)
        
        // Check uniform access
        assert.True(t, bucket.UniformBucketLevelAccess)
        
        // Check website configuration
        assert.Equal(t, "index.html", bucket.Website.MainPageSuffix)
        assert.Equal(t, "404.html", bucket.Website.NotFoundPage)
        
        // Check CORS configuration
        require.Len(t, bucket.CORS, 1)
        assert.Contains(t, bucket.CORS[0].Origins, "https://example.com")
        assert.Contains(t, bucket.CORS[0].Methods, "GET")
        assert.Equal(t, 3600, bucket.CORS[0].MaxAge)
        
        // Check lifecycle rules
        require.Len(t, bucket.Lifecycle.Rules, 2)
        
        // Check retention policy
        assert.NotNil(t, bucket.RetentionPolicy)
        assert.Equal(t, int64(604800), bucket.RetentionPolicy.RetentionPeriod)
        
        // Check labels
        assert.Equal(t, "test", bucket.Labels["environment"])
        assert.Equal(t, "module-testing", bucket.Labels["purpose"])
        assert.Equal(t, "all", bucket.Labels["features"])
        
        // Check soft delete policy
        assert.NotNil(t, bucket.SoftDeletePolicy)
        assert.Equal(t, int64(7*86400), bucket.SoftDeletePolicy.RetentionDuration)
    })

    // Test IAM permissions
    t.Run("IAMPermissions", func(t *testing.T) {
        // Create a test object
        ctx := context.Background()
        client, err := storage.NewClient(ctx, option.WithScopes(storage.ScopeReadWrite))
        require.NoError(t, err)
        defer client.Close()
        
        // Create a test object in the advanced bucket
        bucketHandle := client.Bucket(advancedBucketName)
        objHandle := bucketHandle.Object("test-object.txt")
        w := objHandle.NewWriter(ctx)
        _, err = fmt.Fprintf(w, "test content")
        require.NoError(t, err)
        require.NoError(t, w.Close())
        
        // Verify IAM permissions using the service account
        // This is a simplified check - in a real test, you would impersonate the service account
        policy, err := bucketHandle.IAM().Policy(ctx)
        require.NoError(t, err)
        
        foundViewer := false
        foundCreator := false
        
        for _, binding := range policy.Bindings {
            if binding.Role == "roles/storage.objectViewer" {
                for _, member := range binding.Members {
                    if strings.Contains(member, serviceAcctEmail) {
                        foundViewer = true
                        break
                    }
                }
            }
            if binding.Role == "roles/storage.objectCreator" {
                for _, member := range binding.Members {
                    if strings.Contains(member, serviceAcctEmail) {
                        foundCreator = true
                        break
                    }
                }
            }
        }
        
        assert.True(t, foundViewer, "Service account should have objectViewer role")
        assert.True(t, foundCreator, "Service account should have objectCreator role")
        
        // Clean up test object
        require.NoError(t, objHandle.Delete(ctx))
    })
    
    // Test regional replication if enabled
    regionalReplicationSourceBucket := terraform.OutputMap(t, terraformOptions, "regional_replication_source_bucket_name")
    if regionalReplicationSourceBucket != nil && regionalReplicationSourceBucket["value"] != "" {
        t.Run("RegionalReplication", func(t *testing.T) {
            sourceBucketName := regionalReplicationSourceBucket["value"]
            destBucketName := terraform.Output(t, terraformOptions, "regional_replication_destination_bucket_name")
            
            // Verify both buckets exist
            assertBucketExists(t, projectID, sourceBucketName)
            assertBucketExists(t, projectID, destBucketName)
            
            // Verify transfer job exists
            ctx := context.Background()
            transferService, err := storagetransfer.NewService(ctx)
            require.NoError(t, err)
            
            // List transfer jobs
            jobsResponse, err := transferService.TransferJobs.List().ProjectId(projectID).PageSize(100).Do()
            require.NoError(t, err)
            
            foundJob := false
            for _, job := range jobsResponse.TransferJobs {
                if strings.Contains(job.Description, sourceBucketName) && 
                   strings.Contains(job.TransferSpec.GcsDataSource.BucketName, sourceBucketName) &&
                   strings.Contains(job.TransferSpec.GcsDataSink.BucketName, destBucketName) {
                    foundJob = true
                    break
                }
            }
            
            assert.True(t, foundJob, "Regional replication transfer job should exist")
        })
    }
    
    // Test VPC Service Controls if enabled
    vpcScBucketName := terraform.OutputMap(t, terraformOptions, "vpc_sc_bucket_name")
    if vpcScBucketName != nil && vpcScBucketName["value"] != "" {
        t.Run("VPCServiceControls", func(t *testing.T) {
            bucketName := vpcScBucketName["value"]
            assertBucketExists(t, projectID, bucketName)
            
            // Note: Full VPC-SC testing requires more complex setup and is typically done in integration tests
            // This test just verifies the bucket was created successfully
            bucket := getBucket(t, projectID, bucketName)
            assert.Equal(t, "vpc-sc-testing", bucket.Labels["purpose"])
        })
    }
    
    // Test monitoring alerts if enabled
    monitoringBucketName := terraform.OutputMap(t, terraformOptions, "monitoring_bucket_name")
    if monitoringBucketName != nil && monitoringBucketName["value"] != "" {
        t.Run("MonitoringAlerts", func(t *testing.T) {
            bucketName := monitoringBucketName["value"]
            assertBucketExists(t, projectID, bucketName)
            
            // Verify alert policy exists
            ctx := context.Background()
            monitoringService, err := monitoring.NewService(ctx)
            require.NoError(t, err)
            
            // List alert policies
            alertsResponse, err := monitoringService.Projects.AlertPolicies.List(fmt.Sprintf("projects/%s", projectID)).Do()
            require.NoError(t, err)
            
            foundPolicy := false
            for _, policy := range alertsResponse.AlertPolicies {
                if strings.Contains(policy.DisplayName, bucketName) {
                    foundPolicy = true
                    break
                }
            }
            
            assert.True(t, foundPolicy, "Monitoring alert policy should exist")
        })
    }
}

// Helper function to assert that a bucket exists
func assertBucketExists(t *testing.T, projectID, bucketName string) {
    ctx := context