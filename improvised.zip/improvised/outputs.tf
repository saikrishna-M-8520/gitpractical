/**
 * # GCS Bucket Module Outputs
 *
 * This file defines all outputs from the GCS bucket module.
 */

output "bucket" {
  description = "The created storage bucket"
  value       = google_storage_bucket.gcs_bucket
}

output "bucket_name" {
  description = "The name of the bucket"
  value       = google_storage_bucket.gcs_bucket.name
}

output "bucket_url" {
  description = "The URL of the created bucket"
  value       = "gs://${google_storage_bucket.gcs_bucket.name}"
}

output "bucket_self_link" {
  description = "The self_link of the created bucket"
  value       = google_storage_bucket.gcs_bucket.self_link
}

output "bucket_location" {
  description = "The location of the bucket"
  value       = google_storage_bucket.gcs_bucket.location
}

output "bucket_storage_class" {
  description = "The storage class of the bucket"
  value       = google_storage_bucket.gcs_bucket.storage_class
}

output "bucket_lifecycle_rules" {
  description = "The lifecycle rules of the bucket"
  value       = google_storage_bucket.gcs_bucket.lifecycle_rule
}

output "bucket_versioning_enabled" {
  description = "Whether versioning is enabled on the bucket"
  value       = google_storage_bucket.gcs_bucket.versioning[*].enabled
}

output "bucket_uniform_access" {
  description = "Whether uniform bucket-level access is enabled"
  value       = google_storage_bucket.gcs_bucket.uniform_bucket_level_access
}

output "bucket_encryption" {
  description = "The encryption configuration of the bucket"
  value       = google_storage_bucket.gcs_bucket.encryption
}

output "bucket_labels" {
  description = "The labels assigned to the bucket"
  value       = google_storage_bucket.gcs_bucket.labels
}

output "bucket_website" {
  description = "The website configuration of the bucket"
  value       = google_storage_bucket.gcs_bucket.website
}

output "bucket_cors" {
  description = "The CORS configuration of the bucket"
  value       = google_storage_bucket.gcs_bucket.cors
}

output "bucket_retention_policy" {
  description = "The retention policy of the bucket"
  value       = google_storage_bucket.gcs_bucket.retention_policy
}

output "bucket_logging" {
  description = "The logging configuration of the bucket"
  value       = google_storage_bucket.gcs_bucket.logging
}

output "bucket_iam_members" {
  description = "The IAM members with access to the bucket"
  value       = { for k, v in google_storage_bucket_iam_member.gcs_bucket_iam_members : k => v.member }
}

output "replication_job_name" {
  description = "The name of the cross-region replication job if configured"
  value       = var.replication_config != null ? google_storage_transfer_job.gcs_replication_job[0].name : null
}

output "regional_replication_job_name" {
  description = "The name of the regional replication job if configured"
  value       = var.regional_replication_config != null ? google_storage_transfer_job.gcs_regional_replication_job[0].name : null
}

output "turbo_replication_function" {
  description = "The Cloud Function for turbo replication if configured"
  value       = var.turbo_replication_config != null ? google_cloudfunctions_function.gcs_turbo_replication_function[0].name : null
}

output "notification_id" {
  description = "The ID of the notification configuration if enabled"
  value       = var.notification_config != null ? google_storage_notification.gcs_notification[0].notification_id : null
}

output "bucket_autoclass" {
  description = "The autoclass configuration of the bucket"
  value       = google_storage_bucket.gcs_bucket.autoclass
}

output "bucket_hierarchical_namespace" {
  description = "The hierarchical namespace configuration of the bucket"
  value       = google_storage_bucket.gcs_bucket.hierarchical_namespace
}

output "bucket_soft_delete_policy" {
  description = "The soft delete policy configuration of the bucket"
  value       = google_storage_bucket.gcs_bucket.soft_delete_policy
}

output "vpc_sc_perimeter_name" {
  description = "The name of the VPC Service Controls perimeter if configured"
  value       = var.vpc_sc_config != null ? google_access_context_manager_service_perimeter.gcs_vpc_sc_perimeter[0].name : null
}

output "monitoring_alert_policy_name" {
  description = "The name of the monitoring alert policy if configured"
  value       = var.monitoring_alert_config != null ? google_monitoring_alert_policy.gcs_bucket_alert_policy[0].name : null
}

output "hybrid_transfer_job_name" {
  description = "The name of the hybrid transfer job if configured"
  value       = var.hybrid_transfer_config != null ? google_storage_transfer_job.gcs_hybrid_transfer_job[0].name : null
}