/**
 * # GCS Bucket Module Variables
 *
 * This file defines all input variables for the GCS bucket module.
 */

# Basic bucket configuration
variable "bucket_name" {
  description = "The name of the bucket"
  type        = string
  default     = "dev-bucket"
}

variable "bucket_prefix" {
  description = "Optional prefix for the bucket name"
  type        = string
  default     = null
}

variable "project_id" {
  description = "The ID of the project to create the bucket in"
  type        = string
}

variable "location" {
  description = "The location of the bucket"
  type        = string
  default     = "us-central1"
}

variable "storage_class" {
  description = "The Storage Class of the bucket"
  type        = string
  default     = "STANDARD"
  validation {
    condition     = contains(["STANDARD", "MULTI_REGIONAL", "REGIONAL", "NEARLINE", "COLDLINE", "ARCHIVE"], var.storage_class)
    error_message = "Storage class must be one of: STANDARD, MULTI_REGIONAL, REGIONAL, NEARLINE, COLDLINE, ARCHIVE."
  }
}

variable "labels" {
  description = "A map of key/value label pairs to assign to the bucket"
  type        = map(string)
  default     = {}
}

variable "force_destroy" {
  description = "When deleting a bucket, this boolean option will delete all contained objects"
  type        = bool
  default     = false
}

# Access control
variable "uniform_bucket_level_access" {
  description = "Enables uniform bucket-level access"
  type        = bool
  default     = true
}

variable "public_access_prevention" {
  description = "Prevents public access to the bucket"
  type        = bool
  default     = true
}

variable "requester_pays" {
  description = "Enables Requester Pays on the bucket"
  type        = bool
  default     = false
}

# Versioning
variable "versioning_enabled" {
  description = "Enables versioning for the bucket"
  type        = bool
  default     = true
}

# Encryption
variable "encryption_key" {
  description = "The full resource name of the Cloud KMS key to use for bucket encryption"
  type        = string
  default     = null
}

# Website configuration
variable "website" {
  description = "Map of website configuration values"
  type = object({
    main_page_suffix = string
    not_found_page   = string
  })
  default = null
}

# CORS configuration
variable "cors_rules" {
  description = "List of CORS rules to apply to the bucket"
  type = list(object({
    origin          = list(string)
    method          = list(string)
    response_header = list(string)
    max_age_seconds = number
  }))
  default = null
}

# Lifecycle rules
variable "lifecycle_rules" {
  description = "List of lifecycle rules to configure"
  type = list(object({
    action = object({
      type          = string
      storage_class = optional(string)
    })
    condition = object({
      age                        = optional(number)
      created_before             = optional(string)
      with_state                 = optional(string)
      matches_storage_class      = optional(list(string))
      num_newer_versions         = optional(number)
      days_since_noncurrent_time = optional(number)
      custom_time_before         = optional(string)
    })
  }))
  default = null
}

# Retention policy
variable "retention_policy" {
  description = "Configuration for the bucket's retention policy"
  type = object({
    retention_period = number
    is_locked        = optional(bool, false)
  })
  default = null
}

# Logging configuration
variable "logging_config" {
  description = "The bucket's logging configuration"
  type = object({
    log_bucket        = string
    log_object_prefix = optional(string)
  })
  default = null
}

# IAM configuration
variable "iam_members" {
  description = "Map of member/role pairs to add to the bucket"
  type        = map(list(string))
  default     = {}
}

variable "iam_conditions" {
  description = "Map of IAM conditions for specific members"
  type = map(object({
    title       = string
    description = optional(string)
    expression  = string
  }))
  default = null
}

# Notification configuration
variable "notification_config" {
  description = "The notification configuration of the bucket"
  type = object({
    topic           = string
    payload_format  = string
    event_types     = optional(list(string))
    custom_attributes = optional(map(string))
  })
  default = null
}

# Cross-region replication configuration
variable "replication_config" {
  description = "Configuration for bucket replication using Storage Transfer Service"
  type = object({
    destination_bucket = string
    overwrite_destination = bool
    schedule = object({
      year    = number
      month   = number
      day     = number
      hours   = optional(number, 0)
      minutes = optional(number, 0)
      seconds = optional(number, 0)
      nanos   = optional(number, 0)
    })
    repeat_interval = string
  })
  default = null
}

# Regional replication configuration
variable "regional_replication_config" {
  description = "Configuration for regional bucket replication"
  type = object({
    destination_bucket = string
    overwrite_destination = bool
    min_time_elapsed_seconds = optional(number, 600)
    include_prefixes = optional(list(string))
    exclude_prefixes = optional(list(string))
    schedule = object({
      year    = number
      month   = number
      day     = number
      hours   = optional(number, 0)
      minutes = optional(number, 0)
      seconds = optional(number, 0)
    })
    repeat_interval = string
  })
  default = null
}

# Turbo Replication configuration
variable "turbo_replication_config" {
  description = "Configuration for turbo replication using Cloud Functions"
  type = object({
    destination_bucket = string
    destination_location = optional(string)
    create_destination_bucket = optional(bool, false)
    destination_storage_class = optional(string, "STANDARD")
    function_region = string
    function_source_bucket = string
    function_source_object = string
    function_memory_mb = optional(number, 256)
    include_patterns = optional(list(string), [])
    exclude_patterns = optional(list(string), [])
  })
  default = null
}

# Autoclass configuration
variable "autoclass_enabled" {
  description = "Enables Autoclass feature for automatic storage class optimization"
  type        = bool
  default     = false
}

variable "autoclass_terminal_storage_class" {
  description = "The terminal storage class for Autoclass"
  type        = string
  default     = "ARCHIVE"
  validation {
    condition     = contains(["NEARLINE", "COLDLINE", "ARCHIVE"], var.autoclass_terminal_storage_class)
    error_message = "Terminal storage class must be one of: NEARLINE, COLDLINE, ARCHIVE."
  }
}

variable "autoclass_terminal_storage_class_days" {
  description = "The number of days before objects are transitioned to the terminal storage class"
  type        = number
  default     = 365
}

# Custom placement configuration
variable "custom_placement_config" {
  description = "The bucket's custom placement configuration for dual-region buckets"
  type = object({
    data_locations = list(string)
  })
  default = null
}

# Hierarchical namespace
variable "hierarchical_namespace_enabled" {
  description = "Enables hierarchical namespace for the bucket"
  type        = bool
  default     = false
}

# Soft delete policy
variable "soft_delete_policy_retention_duration_days" {
  description = "The retention duration in days for the soft delete policy"
  type        = number
  default     = 7
}

# VPC Service Controls configuration
variable "vpc_sc_config" {
  description = "Configuration for VPC Service Controls integration"
  type = object({
    access_policy = string
    access_level = string
    allowed_egress_identities = optional(list(string), [])
  })
  default = null
}

# Audit logging configuration
variable "enable_audit_logging" {
  description = "Enable audit logging for the bucket"
  type        = bool
  default     = true
}

# Monitoring alert configuration
variable "monitoring_alert_config" {
  description = "Configuration for Cloud Monitoring alerting policies"
  type = object({
    access_denied_threshold = number
    unusual_access_threshold = number
    duration = string
    alignment_period = string
    trigger_count = number
    notification_channels = list(string)
  })
  default = null
}

# Hybrid cloud transfer configuration
variable "hybrid_transfer_config" {
  description = "Configuration for hybrid cloud transfer (AWS S3, Azure, HTTP, POSIX)"
  type = object({
    transfer_type = string
    # AWS S3 specific
    source_aws_bucket = optional(string)
    aws_access_key_id = optional(string)
    aws_secret_access_key = optional(string)
    # Azure specific
    azure_container = optional(string)
    azure_storage_account = optional(string)
    azure_sas_token = optional(string)
    # HTTP specific
    http_list_url = optional(string)
    # POSIX specific
    posix_root_directory = optional(string)
    # Common options
    destination_path = optional(string, "")
    delete_from_source = optional(bool, false)
    overwrite_destination = optional(bool, true)
    object_conditions = optional(object({
      min_time_elapsed_seconds = optional(number)
      max_time_elapsed_seconds = optional(number)
      include_prefixes = optional(list(string))
      exclude_prefixes = optional(list(string))
    }))
    schedule = object({
      year = number
      month = number
      day = number
      hours = optional(number, 0)
      minutes = optional(number, 0)
      seconds = optional(number, 0)
      nanos = optional(number, 0)
    })
    repeat_interval = optional(string, "86400s")
  })
  default = null
  
  validation {
    condition = var.hybrid_transfer_config == null || contains(["AWS_S3", "AZURE_BLOB", "HTTP", "POSIX"], var.hybrid_transfer_config.transfer_type)
    error_message = "Transfer type must be one of: AWS_S3, AZURE_BLOB, HTTP, POSIX."
  }
  
  validation {
    condition = var.hybrid_transfer_config == null || var.hybrid_transfer_config.transfer_type != "AWS_S3" || (var.hybrid_transfer_config.source_aws_bucket != null && var.hybrid_transfer_config.aws_access_key_id != null && var.hybrid_transfer_config.aws_secret_access_key != null)
    error_message = "AWS S3 transfer requires source_aws_bucket, aws_access_key_id, and aws_secret_access_key."
  }
  
  validation {
    condition = var.hybrid_transfer_config == null || var.hybrid_transfer_config.transfer_type != "AZURE_BLOB" || (var.hybrid_transfer_config.azure_container != null && var.hybrid_transfer_config.azure_storage_account != null && var.hybrid_transfer_config.azure_sas_token != null)
    error_message = "Azure Blob transfer requires azure_container, azure_storage_account, and azure_sas_token."
  }
  
  validation {
    condition = var.hybrid_transfer_config == null || var.hybrid_transfer_config.transfer_type != "HTTP" || var.hybrid_transfer_config.http_list_url != null
    error_message = "HTTP transfer requires http_list_url."
  }
  
  validation {
    condition = var.hybrid_transfer_config == null || var.hybrid_transfer_config.transfer_type != "POSIX" || var.hybrid_transfer_config.posix_root_directory != null
    error_message = "POSIX transfer requires posix_root_directory."
  }
}