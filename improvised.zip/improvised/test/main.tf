/**
 * # GCS Bucket Module Test
 *
 * This file contains test configurations for the GCS bucket module.
 */

provider "google" {
  project = var.project_id
  region  = var.region
}

provider "google-beta" {
  project = var.project_id
  region  = var.region
}

# Generate a random suffix to ensure unique bucket names
resource "random_id" "bucket_suffix" {
  byte_length = 4
}

locals {
  test_bucket_name = "${var.test_bucket_prefix}-${random_id.bucket_suffix.hex}"
}

# Basic bucket with minimal configuration
module "gcs_basic" {
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-basic"
  location    = var.region
  labels = {
    environment = "test"
    purpose     = "module-testing"
  }
}

# Advanced bucket with all features enabled
module "gcs_advanced" {
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-advanced"
  location    = var.region
  
  # Storage configuration
  storage_class = "STANDARD"
  
  # Access control
  uniform_bucket_level_access = true
  public_access_prevention    = true
  
  # Versioning
  versioning_enabled = true
  
  # Encryption (using Google-managed keys for testing)
  # For CMEK testing, uncomment and provide a valid KMS key
  # encryption_key = "projects/${var.project_id}/locations/${var.region}/keyRings/${var.kms_keyring_name}/cryptoKeys/${var.kms_key_name}"
  
  # Lifecycle rules
  lifecycle_rules = [
    {
      action = {
        type          = "SetStorageClass"
        storage_class = "NEARLINE"
      }
      condition = {
        age                   = 30
        matches_storage_class = ["STANDARD"]
      }
    },
    {
      action = {
        type = "Delete"
      }
      condition = {
        age                   = 90
        matches_storage_class = ["NEARLINE"]
      }
    }
  ]
  
  # Retention policy (7 days)
  retention_policy = {
    retention_period = 604800 # 7 days in seconds
    is_locked        = false
  }
  
  # CORS configuration
  cors_rules = [
    {
      origin          = ["https://example.com"]
      method          = ["GET", "HEAD", "OPTIONS"]
      response_header = ["Content-Type", "Access-Control-Allow-Origin"]
      max_age_seconds = 3600
    }
  ]
  
  # Website configuration
  website = {
    main_page_suffix = "index.html"
    not_found_page   = "404.html"
  }
  
  # IAM configuration
  iam_members = {
    "serviceAccount:${var.test_service_account}" = [
      "roles/storage.objectViewer",
      "roles/storage.objectCreator"
    ]
  }
  
  # IAM conditions
  iam_conditions = {
    "serviceAccount:${var.test_service_account}" = {
      title       = "test-condition"
      description = "Test IAM condition"
      expression  = "resource.name.startsWith(\"projects/_/buckets/${local.test_bucket_name}-advanced/objects/test-\")"
    }
  }
  
  # Logging configuration
  logging_config = {
    log_bucket = module.gcs_basic.bucket_name
  }
  
  # Soft delete policy (7 days)
  soft_delete_policy_retention_duration_days = 7
  
  # Autoclass configuration
  autoclass_enabled = true
  autoclass_terminal_storage_class = "ARCHIVE"
  autoclass_terminal_storage_class_days = 90
  
  # Hierarchical namespace
  hierarchical_namespace_enabled = false
  
  # Enable audit logging
  enable_audit_logging = true
  
  # Labels
  labels = {
    environment = "test"
    purpose     = "module-testing"
    features    = "all"
  }
  
  depends_on = [module.gcs_basic]
}

# Bucket with VPC Service Controls integration
module "gcs_vpc_sc" {
  count       = var.enable_vpc_sc_test ? 1 : 0
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-vpcsc"
  location    = var.region
  
  # VPC Service Controls configuration
  vpc_sc_config = {
    access_policy = var.vpc_sc_access_policy
    access_level  = var.vpc_sc_access_level
    allowed_egress_identities = [
      "serviceAccount:${var.test_service_account}"
    ]
  }
  
  labels = {
    environment = "test"
    purpose     = "vpc-sc-testing"
  }
}

# Bucket with regional replication
module "gcs_regional_replication" {
  count       = var.enable_replication_test ? 1 : 0
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-regional-source"
  location    = var.region
  
  # Create a destination bucket first
  depends_on = [module.gcs_regional_replication_destination]
  
  # Regional replication configuration
  regional_replication_config = {
    destination_bucket = module.gcs_regional_replication_destination[0].bucket_name
    overwrite_destination = true
    min_time_elapsed_seconds = 60
    include_prefixes = ["test/"]
    schedule = {
      year  = 2023
      month = 1
      day   = 1
    }
    repeat_interval = "3600s" # Hourly
  }
  
  labels = {
    environment = "test"
    purpose     = "replication-testing"
    role        = "source"
  }
}

# Destination bucket for regional replication
module "gcs_regional_replication_destination" {
  count       = var.enable_replication_test ? 1 : 0
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-regional-dest"
  location    = var.region == "us-central1" ? "us-east1" : "us-central1" # Different region
  
  labels = {
    environment = "test"
    purpose     = "replication-testing"
    role        = "destination"
  }
}

# Bucket with turbo replication
module "gcs_turbo_replication" {
  count       = var.enable_turbo_replication_test && var.turbo_replication_function_source_bucket != null ? 1 : 0
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-turbo-source"
  location    = var.region
  
  # Turbo replication configuration
  turbo_replication_config = {
    destination_bucket = "${local.test_bucket_name}-turbo-dest"
    destination_location = var.region == "us-central1" ? "us-east1" : "us-central1"
    create_destination_bucket = true
    function_region = var.region
    function_source_bucket = var.turbo_replication_function_source_bucket
    function_source_object = var.turbo_replication_function_source_object
    include_patterns = ["*.jpg", "*.png"]
  }
  
  labels = {
    environment = "test"
    purpose     = "turbo-replication-testing"
  }
}

# Bucket with monitoring alerts
module "gcs_monitoring" {
  count       = var.enable_monitoring_test && length(var.monitoring_notification_channels) > 0 ? 1 : 0
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-monitoring"
  location    = var.region
  
  # Monitoring alert configuration
  monitoring_alert_config = {
    access_denied_threshold = 10
    unusual_access_threshold = 100
    duration = "300s"
    alignment_period = "60s"
    trigger_count = 1
    notification_channels = var.monitoring_notification_channels
  }
  
  labels = {
    environment = "test"
    purpose     = "monitoring-testing"
  }
}

# Bucket with hybrid cloud transfer
module "gcs_hybrid_transfer" {
  count       = var.enable_hybrid_transfer_test && var.hybrid_transfer_type != null ? 1 : 0
  source      = "../"
  project_id  = var.project_id
  bucket_name = "${local.test_bucket_name}-hybrid"
  location    = var.region
  
  # Hybrid transfer configuration - conditionally set based on transfer type
  hybrid_transfer_config = var.hybrid_transfer_type == "AWS_S3" ? {
    transfer_type = "AWS_S3"
    source_aws_bucket = var.aws_source_bucket
    aws_access_key_id = var.aws_access_key_id
    aws_secret_access_key = var.aws_secret_access_key
    schedule = {
      year = 2023
      month = 1
      day = 1
    }
  } : var.hybrid_transfer_type == "HTTP" ? {
    transfer_type = "HTTP"
    http_list_url = var.http_list_url
    schedule = {
      year = 2023
      month = 1
      day = 1
    }
  } : var.hybrid_transfer_type == "AZURE_BLOB" ? {
    transfer_type = "AZURE_BLOB"
    azure_container = var.azure_container
    azure_storage_account = var.azure_storage_account
    azure_sas_token = var.azure_sas_token
    schedule = {
      year = 2023
      month = 1
      day = 1
    }
  } : {
    transfer_type = "POSIX"
    posix_root_directory = var.posix_root_directory
    schedule = {
      year = 2023
      month = 1
      day = 1
    }
  }
  
  labels = {
    environment = "test"
    purpose     = "hybrid-transfer-testing"
  }
}

# Output the bucket names for testing
output "basic_bucket_name" {
  value = module.gcs_basic.bucket_name
}

output "advanced_bucket_name" {
  value = module.gcs_advanced.bucket_name
}

output "vpc_sc_bucket_name" {
  value = var.enable_vpc_sc_test ? module.gcs_vpc_sc[0].bucket_name : null
}

output "regional_replication_source_bucket_name" {
  value = var.enable_replication_test ? module.gcs_regional_replication[0].bucket_name : null
}

output "regional_replication_destination_bucket_name" {
  value = var.enable_replication_test ? module.gcs_regional_replication_destination[0].bucket_name : null
}

output "turbo_replication_source_bucket_name" {
  value = var.enable_turbo_replication_test && var.turbo_replication_function_source_bucket != null ? module.gcs_turbo_replication[0].bucket_name : null
}

output "monitoring_bucket_name" {
  value = var.enable_monitoring_test && length(var.monitoring_notification_channels) > 0 ? module.gcs_monitoring[0].bucket_name : null
}

output "hybrid_transfer_bucket_name" {
  value = var.enable_hybrid_transfer_test && var.hybrid_transfer_type != null ? module.gcs_hybrid_transfer[0].bucket_name : null
}