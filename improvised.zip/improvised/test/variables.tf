/**
 * # GCS Bucket Module Test Variables
 *
 * This file defines variables used in the test configuration.
 */

variable "project_id" {
  description = "The ID of the project to create resources in"
  type        = string
}

variable "region" {
  description = "The region to create resources in"
  type        = string
  default     = "us-central1"
}

variable "test_bucket_prefix" {
  description = "Prefix for test bucket names"
  type        = string
  default     = "tf-test-bucket"
}

variable "test_service_account" {
  description = "Service account email to use for IAM testing"
  type        = string
}

variable "kms_keyring_name" {
  description = "Name of the KMS keyring for CMEK testing"
  type        = string
  default     = "test-keyring"
}

variable "kms_key_name" {
  description = "Name of the KMS key for CMEK testing"
  type        = string
  default     = "test-key"
}

# VPC Service Controls testing
variable "enable_vpc_sc_test" {
  description = "Enable testing of VPC Service Controls integration"
  type        = bool
  default     = false
}

variable "vpc_sc_access_policy" {
  description = "Access policy ID for VPC Service Controls"
  type        = string
  default     = ""
}

variable "vpc_sc_access_level" {
  description = "Access level for VPC Service Controls"
  type        = string
  default     = ""
}

# Replication testing
variable "enable_replication_test" {
  description = "Enable testing of regional replication"
  type        = bool
  default     = false
}

# Turbo replication testing
variable "enable_turbo_replication_test" {
  description = "Enable testing of turbo replication"
  type        = bool
  default     = false
}

variable "turbo_replication_function_source_bucket" {
  description = "Bucket containing the Cloud Function source code for turbo replication"
  type        = string
  default     = null
}

variable "turbo_replication_function_source_object" {
  description = "Object path to the Cloud Function source code for turbo replication"
  type        = string
  default     = "function-source.zip"
}

# Monitoring testing
variable "enable_monitoring_test" {
  description = "Enable testing of monitoring alerts"
  type        = bool
  default     = false
}

variable "monitoring_notification_channels" {
  description = "List of notification channel IDs for monitoring alerts"
  type        = list(string)
  default     = []
}

# Hybrid transfer testing
variable "enable_hybrid_transfer_test" {
  description = "Enable testing of hybrid cloud transfer"
  type        = bool
  default     = false
}

variable "hybrid_transfer_type" {
  description = "Type of hybrid transfer to test (AWS_S3, HTTP, AZURE_BLOB, POSIX)"
  type        = string
  default     = null
}

# AWS S3 transfer variables
variable "aws_source_bucket" {
  description = "AWS S3 source bucket for hybrid transfer"
  type        = string
  default     = null
}

variable "aws_access_key_id" {
  description = "AWS access key ID for hybrid transfer"
  type        = string
  default     = null
  sensitive   = true
}

variable "aws_secret_access_key" {
  description = "AWS secret access key for hybrid transfer"
  type        = string
  default     = null
  sensitive   = true
}

# HTTP transfer variables
variable "http_list_url" {
  description = "HTTP list URL for hybrid transfer"
  type        = string
  default     = null
}

# Azure Blob transfer variables
variable "azure_container" {
  description = "Azure Blob container for hybrid transfer"
  type        = string
  default     = null
}

variable "azure_storage_account" {
  description = "Azure storage account for hybrid transfer"
  type        = string
  default     = null
}

variable "azure_sas_token" {
  description = "Azure SAS token for hybrid transfer"
  type        = string
  default     = null
  sensitive   = true
}

# POSIX transfer variables
variable "posix_root_directory" {
  description = "POSIX root directory for hybrid transfer"
  type        = string
  default     = null
}