# GCS Bucket Module Test Configuration

# Project and region
project_id = "my-test-project"
region     = "us-central1"

# Test configuration
test_bucket_prefix   = "tf-test-bucket"
test_service_account = "test-sa@my-test-project.iam.gserviceaccount.com"

# KMS configuration for CMEK testing
kms_keyring_name = "test-keyring"
kms_key_name     = "test-key"

# VPC Service Controls testing
enable_vpc_sc_test = false
vpc_sc_access_policy = "123456789"
vpc_sc_access_level = "accessPolicies/123456789/accessLevels/my_access_level"

# Replication testing
enable_replication_test = false

# Turbo replication testing
enable_turbo_replication_test = false
turbo_replication_function_source_bucket = "my-function-source-bucket"
turbo_replication_function_source_object = "turbo-replication-function.zip"

# Monitoring testing
enable_monitoring_test = false
monitoring_notification_channels = [
  "projects/my-test-project/notificationChannels/12345678901234567890"
]

# Hybrid transfer testing
enable_hybrid_transfer_test = false
hybrid_transfer_type = null

# AWS S3 transfer configuration
aws_source_bucket = "my-aws-source-bucket"
aws_access_key_id = ""
aws_secret_access_key = ""

# HTTP transfer configuration
http_list_url = "https://example.com/file-list.txt"

# Azure Blob transfer configuration
azure_container = "my-azure-container"
azure_storage_account = "myazurestorageaccount"
azure_sas_token = ""

# POSIX transfer configuration
posix_root_directory = "/mnt/data"